#!/usr/bin/env bash
killall polybar || true
polybar main &
