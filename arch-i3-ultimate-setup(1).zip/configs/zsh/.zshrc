eval "$(starship init zsh)"
eval "$(zoxide init zsh)"

alias ls="eza --icons"
alias ll="eza -lh --icons"
alias tree="eza --tree"
alias y="yazi"

fastfetch
