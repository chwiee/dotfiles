#!/usr/bin/env bash
DIR=~/Pictures/Wallpapers
img=$(ls $DIR 2>/dev/null | shuf -n1)
if [ -n "$img" ]; then
 feh --bg-fill "$DIR/$img"
 wal -i "$DIR/$img"
fi
