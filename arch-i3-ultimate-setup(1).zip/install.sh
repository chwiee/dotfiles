#!/usr/bin/env bash
set -e

echo "=== Installing Arch i3 Ultimate Setup ==="

sudo pacman -Sy --noconfirm

sudo pacman -S --needed --noconfirm \
  xorg-server xorg-xinit xorg-xrandr \
  i3-wm i3status i3lock \
  kitty rofi picom feh polybar \
  networkmanager network-manager-applet \
  bluez bluez-utils blueman \
  pipewire pipewire-pulse wireplumber pavucontrol \
  flameshot dunst \
  git curl unzip jq \
  zsh starship neovim \
  fastfetch btop fzf zoxide eza yazi \
  docker kubectl \
  python-pywal imagemagick \
  brightnessctl \
  ttf-fira-code ttf-nerd-fonts-symbols

sudo systemctl enable NetworkManager
sudo systemctl enable bluetooth
sudo systemctl enable docker

echo "Installing LazyDocker"
LAZYDOCKER_VERSION=$(curl -s https://api.github.com/repos/jesseduffield/lazydocker/releases/latest | jq -r .tag_name)
curl -L https://github.com/jesseduffield/lazydocker/releases/download/${LAZYDOCKER_VERSION}/lazydocker_${LAZYDOCKER_VERSION#v}_Linux_x86_64.tar.gz -o lazydocker.tar.gz
tar xf lazydocker.tar.gz
sudo install lazydocker /usr/local/bin
rm -rf lazydocker*

echo "Installing LazyKubernetes"
curl -L https://github.com/jesseduffield/lazykubernetes/releases/latest/download/lazykubernetes_Linux_x86_64.tar.gz -o lazykubernetes.tar.gz || true
tar xf lazykubernetes.tar.gz || true
sudo install lazykubernetes /usr/local/bin || true
rm -rf lazykubernetes*

echo "Installing LazyVim"
if [ ! -d ~/.config/nvim ]; then
 git clone https://github.com/LazyVim/starter ~/.config/nvim
 rm -rf ~/.config/nvim/.git
fi

echo "Copying configs"
cp -r configs/* ~/.config/

chmod +x ~/.config/scripts/*.sh || true
chmod +x ~/.config/polybar/launch.sh || true

mkdir -p ~/Pictures/Wallpapers

if [ ! -f ~/.xinitrc ]; then
 echo "exec i3" > ~/.xinitrc
fi

chsh -s $(command -v zsh) || true

echo "Installation complete."
echo "Reboot and run: startx"
